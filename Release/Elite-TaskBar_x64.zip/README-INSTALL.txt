Elite-TaskBar Installation Instructions

1. Extract all files from this ZIP archive.
2. Copy ALL of the extracted .exe and .cpl files into your C:\Windows\System32 directory.
3. If prompted by User Account Control (UAC), click Yes to approve the administrator operation.
4. Open the EliteSettings.cpl from your Control Panel or run EliteTaskbar.exe directly!

Note: Do not run the executables from inside the ZIP file or from your Desktop without moving them to System32 first, as they may rely on native DLL paths.
